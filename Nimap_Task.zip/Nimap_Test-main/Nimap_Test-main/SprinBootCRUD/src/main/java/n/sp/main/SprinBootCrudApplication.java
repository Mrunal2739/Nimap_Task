package n.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinBootCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinBootCrudApplication.class, args);
	}

}
 